import allure
import requests
from utils.logger import Logger

'''Список НТТР методов'''
class Http_methods:
    headers = {'Content-Type' : 'application/json'}
    cookie = ''

    @staticmethod #Делаем метод статичным, что позволит вызывать его не опираясь на класс
    def get(url):
        with allure.step('GET'): #Установка тега для allure
            Logger.add_request(url, method='GET') #Логируем запрос
            result = requests.get(url, headers=Http_methods.headers, cookies=Http_methods.cookie)
            Logger.add_response(result) #Логируем ответ
            return result

    @staticmethod
    def post(url, body):
        with allure.step('POST'):  # Установка тега для allure
            Logger.add_request(url, method='POST')  # Логируем запрос
            result = requests.post(url, json=body, headers=Http_methods.headers, cookies=Http_methods.cookie)
            Logger.add_response(result)  # Логируем ответ
            return result

    @staticmethod
    def put(url, body):
        with allure.step('PUT'):  # Установка тега для allure
            Logger.add_request(url, method='PUT')  # Логируем запрос
            result = requests.put(url, json=body, headers=Http_methods.headers, cookies=Http_methods.cookie)
            Logger.add_response(result)  # Логируем ответ
            return result

    @staticmethod
    def delete(url, body):
        with allure.step('DELETE'):  # Установка тега для allure
            Logger.add_request(url, method='DELETE')  # Логируем запрос
            result = requests.delete(url, json=body, headers=Http_methods.headers, cookies=Http_methods.cookie)
            Logger.add_response(result)  # Логируем ответ
            return result