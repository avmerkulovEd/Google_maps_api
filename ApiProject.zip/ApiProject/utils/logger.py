import datetime
import os
from requests import Response

class Logger():
    #Создаем имя файла в папке Lоgs c расширением log
    file_name = f"Logs/log_" + str(datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')) + '.log'

    @classmethod #Метод сможет работать с переменными класса напрямую через cls
    def write_log_to_file(cls, data: str):
        with open(cls.file_name, 'a', encoding='utf=8') as logger_file: #Открываем файл по имени, в режиме добавления, в кодировке utf8
            logger_file.write(data)

    @classmethod  # Метод сможет работать с переменными класса напрямую через cls
    def add_request(cls, url: str, method: str):
        test_name = os.environ.get('PYTEST_CURRENT_TEST')
        data_to_add = f'\n-----\n' #Разделитель
        data_to_add += f'Test: {test_name}\n' #Название теста
        data_to_add += f'Time: {str(datetime.datetime.now())}\n' #Дата
        data_to_add += f'Request method: {method}\n' #Название Метода
        data_to_add += f'Request URL: {url}\n'  # Название URL
        data_to_add += '\n'  # Абзац
        cls.write_log_to_file(data_to_add) #Записываем получившуюся строку в файл

    @classmethod
    def add_response(cls, result: Response):
        cookies_as_dict = dict(result.cookies) #Обращаемся к кукам
        headers_as_dict = dict(result.headers) #Обращаемся к заголовкам
        data_to_add = f'Response code: {result.status_code}\n'
        data_to_add += f'Response text: {result.text}\n'
        data_to_add += f'Response headers: {headers_as_dict}\n'
        data_to_add += f'Response cookies: {cookies_as_dict}\n'
        data_to_add += f'\n-----\n' #Разделитель
        cls.write_log_to_file(data_to_add) #Записываем получившуюся строку в файл
